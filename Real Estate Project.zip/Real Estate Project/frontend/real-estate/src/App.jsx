import './App.css';
import Home from './main/Home';
import { createBrowserRouter, BrowserRouter, Routes, Route, createRoutesFromElements, RouterProvider, Link, Outlet } from "react-router-dom";
import Login from './pages/Login';
import CreateAccount from './pages/CreateAccount';

function App() { 
  return (
    
    <Home/>
  );
}
export default App;
