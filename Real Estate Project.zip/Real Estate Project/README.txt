1.run backend:
1) cd backend
2) npm install
3) npm start

2.run frontend:
1) cd frontend/real-estate
2) npm install
3) npm start